package bcit.gist7010;
//==============================================================================
// File         : Main.java
//
// Current Author: Mostafa Javanmehri
//
// Previous Author: None
//
// Contact Info: m.javanmehri@gmail.com
//
// Purpose : A search and rescue agency needs a tool that will standardize their
// grid searching patterns in the field. The agency wants to preload GPS waypoints
// into their GPS receivers so that their search parties follow a consistent pattern
// and the area has full coverage. The problem we have to solve is as follows: given
// a starting position, an x increment, a y increment and the total number of
// intervals, generate the waypoints i.e. X and Y coordinates separated by a colon.
//
// Dependencies: None
//
// Modification Log :
//    --> Created May-12-2016 (fl)
//    --> Updated MMM-DD-YYYY (fl)
//
// =============================================================================
import org.apache.commons.lang3.math.NumberUtils;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {

        // ===========================================================
        // Redirect standard IN and OUT to files
        // You will need to import the following classes:
        // import java.io.FileInputStream;
        // import java.io.PrintStream;
        //
        // You will also need to add a throw to main:
        // throws Exception
        //
        // Switch standard in (keyboard) to a file
        // Switch standard out (console) to a file
        // ===========================================================
        System.setIn(new FileInputStream("H:/var/gist/7010/wksp_dt/mod_05_GridSearch/gridSearchIn.txt"));
        System.setOut(new PrintStream("H:/var/gist/7010/wksp_dt/mod_05_GridSearch/gridSearchOut.txt"));

        // ===========================================================
        // You will need to import Scanner (see below)
        // import java.util.Scanner;
        //
        // Link a Scanner to the keyboard so that we can capture
        // what the user types at the keyboard and pipe that data
        // into the program for processing
        // ===========================================================
        Scanner keyboard;
        keyboard = new Scanner(System.in);

        String xcoordAsString;

        double xStart, yStart, xInterval, yInterval, iterations;

        boolean atEndOfData = false; // to flag whether you are at the end of the data stream. We assume that we at least one point to mask.

        //

        while (! atEndOfData)
        {
            xcoordAsString = keyboard.next();
            if (! NumberUtils.isNumber(xcoordAsString))
            {
                //===========================================================
                // We just encountered at END, it is time to get out of the loop
                //===========================================================
                atEndOfData = true;
            }
            else
            {
                //===========================================================
                // Almost all of the remaining code will be within this else block
                //===========================================================

                System.out.println("BEGIN");

                //===========================================================
                // Set xStart value from xcoordAsString, and retrieve the other
                // values from input file
                //===========================================================
                xStart = Double.parseDouble(xcoordAsString);
                yStart = keyboard.nextDouble();
                xInterval = keyboard.nextDouble();
                yInterval = keyboard.nextDouble();
                iterations = keyboard.nextDouble();

                System.out.printf("%f:%f%n",xStart,yStart); // Print the start pont

                for (int i=0; i<iterations; i++)
                {
                    System.out.printf("%f:%f%n", xStart, yStart + yInterval); // up
                    System.out.printf("%f:%f%n", xStart+xInterval, yStart+yInterval); // OVER
                    System.out.printf("%f:%f%n", xStart+xInterval, yStart); // DOWN
                    System.out.printf("%f:%f%n", xStart+(2*xInterval), yStart); // OVER
                    xStart = xStart + 2*xInterval; // perform the move

                } // End of the for-loop
                System.out.println("END");

            } // End of the else

        } // End of the while-loop


    }
}
