package bcit.gist7010;
//==============================================================================
// File         : Main.java
//
// Current Author: Mostafa Javanmehri
//
// Previous Author: None
//
// Contact Info: m.javanmehri@gmail.com
//
// Purpose :
//
// Dependencies: None
//
// Modification Log :
//    --> Created May-12-2016 (fl)
//    --> Updated MMM-DD-YYYY (fl)
//
// =============================================================================
import org.apache.commons.lang3.math.NumberUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        System.setOut(new PrintStream("H:/var/gist/7010/m05_data/geoMaskOut.txt"));
        System.setIn(new FileInputStream("H:/var/gist/7010/m05_data/geoMaskIn.txt"));

        Scanner keyboard;
        keyboard = new Scanner(System.in);

        Random rndNumber;
        rndNumber = new Random(25);

        String xcoordAsString;

        //===========================================================
        // The following block defines some double variables ....
        // xcoord --> the original x-ordinate entered by the user
        // ycoord --> the original y-ordinate entered by the user
        // maskingDistance --> the buffer distance that will be used to obscure the original coordinate.
        // deltaX --> the amount that xcoord will be shifted AKA masked
        // deltaY --> the amount that ycoord will be shifted AKA masked
        // maxDeltaXY --> the maximum distance that an ordinate can be shifted and still fall inside the buffered area that would result from the making distance.
        // maskedXcoord --> the new xcoord
        // maskedYcoord --> the new ycoord
        //===========================================================
        double xcoord, ycoord, maskingDistance, deltaX, deltaY, maxDeltaXY, maskedXcoord, maskedYcoord;

        int plusOrMinus; // allows for the change in x or y to be either or negative

        boolean atEndOfData = false; // to flag whether you are at the end of the data stream. We assume that we at least one point to mask.

        System.out.println("xcoord, ycoord");
        while (! atEndOfData)
        {
            xcoordAsString = keyboard.next();
            if (! NumberUtils.isNumber(xcoordAsString))
            {
                //===========================================================
                // We just encountered at END, it is time to get out of the loop
                //===========================================================
                atEndOfData = true;
            } // if xcoord is not a number
            else
            {
                //===========================================================
                // Almost all of the remaining code will be within this else block
                //===========================================================

                xcoord = Double.parseDouble(xcoordAsString); // parse the xcoord value to double
                ycoord = keyboard.nextDouble(); // retrieve the ycoord value as double
                maskingDistance = keyboard.nextDouble(); // retrieve the masking distance value as double

                //===========================================================
                // calculate the maximum distance that an x or y value is allowed
                // to change based on the given masking distance
                //===========================================================
                maxDeltaXY = Math.sqrt(Math.pow(maskingDistance, 2)/2);

                //===========================================================
                // generate the change for X and the change for Y based on the
                // maximum distance allowed.
                //===========================================================
                deltaX = rndNumber.nextDouble()*maxDeltaXY;
                deltaY = rndNumber.nextDouble()*maxDeltaXY;

                //===========================================================
                // Assign a negative or positive sign to the change in X and the
                // change in Y
                //===========================================================
                plusOrMinus = rndNumber.nextInt(2);
                if (plusOrMinus == 0)
                {
                    deltaX = deltaY*-1;
                }
                plusOrMinus = rndNumber.nextInt(2);
                if (plusOrMinus == 0)
                {
                    deltaY = deltaY*-1;
                }

                //===========================================================
                // Adjust the x and y values
                //===========================================================
                maskedXcoord = xcoord + deltaX;
                maskedYcoord = ycoord + deltaY;

                System.out.printf("%f,%f%n", maskedXcoord, maskedYcoord);





            } // if xcoord is a number

        } // End of while loop




    }
}
