package bcit.gist7010;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here

        // Define needed variables

        // input variables
        double fromXcoord;
        double fromYcoord;
        double fromZcoord;
        double toXcoord;
        double toYcoord;
        double toZcoord;

        //  variables used to calculate the distance between the two points
        double xDifference;
        double yDifference;
        double squaredXDifference;
        double squaredYDifference;
        double distanceBetweenPoints;

        // variable used to calculate the change in elevation
        double elevationChange;

        // variables used to claculate the slope
        double riseOverRun;     // change in elevation over the distance
        double slopeRadians;    // slope in radians
        double slopeDegrees;    // slope in degrees
        double percentGrade;
        final double RISERUN2GRADE = 100d;  // a constant for converting from degrees to percent grade

        Scanner input;

        input = new Scanner(System.in);

        // prompt the user for the from X-coordinate value
        System.out.println(" Enter the from X-coordinate:");
        // Assign fromXcoord
        fromXcoord = input.nextDouble();

        // prompt the user for the from Y-coordinate value
        System.out.println(" Enter the from Y-coordinate:");
        // Assign fromYcoord
        fromYcoord = input.nextDouble();

        // prompt the user for the from Z-coordinate value
        System.out.println(" Enter the from Z-coordinate:");
        // Assign the fromZcoord
        fromZcoord = input.nextDouble();


        // prompt the user for the to X-coordinate value
        System.out.println(" Enter the to X-coordinate:");
        // Assign toXcoord
        toXcoord = input.nextDouble();

        // prompt the user for the to Y-coordinate value
        System.out.println(" Enter the to Y-coordinate:");
        // Assign toYcoord
        toYcoord = input.nextDouble();

        // prompt the user for the tom Z-coordinate value
        System.out.println(" Enter the to Z-coordinate:");
        // Assign the toZcoord
        toZcoord = input.nextDouble();

        // Calculate the distance between two points
        xDifference = fromXcoord - toXcoord;
        yDifference = fromYcoord - toYcoord;
        squaredXDifference = Math.pow(xDifference, 2);
        squaredYDifference = Math.pow(yDifference, 2);
        distanceBetweenPoints = Math.sqrt(squaredXDifference+squaredYDifference);

        // Calculate the change in elevation
        elevationChange = toZcoord - fromZcoord;

        // Calculate the slope
        riseOverRun = elevationChange / distanceBetweenPoints;
        slopeRadians = Math.atan(riseOverRun);
        slopeDegrees = Math.abs(Math.toDegrees(slopeRadians));
        percentGrade = Math.abs(riseOverRun*RISERUN2GRADE);

        // Report the percent slope and the slope in degrees
        System.out.printf(" The percent slope is %f %n", percentGrade);
        System.out.printf(" The slope in degrees is %f %n", slopeDegrees);


    }

}
