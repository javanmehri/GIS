package bcit.gist7010;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Scanner keyboard;
        keyboard = new Scanner(System.in);

        String  fromUnit, toUnit, outputMessage="Bad or incomplete logic";

        double fromValue, toValue;

        boolean isKnownConversion=true;

        toValue = Double.NaN;

        System.out.println(" Please type the (value) you want to convert, th (from unit) and the (to unit) respectively.");

        fromValue = keyboard.nextDouble();
        fromUnit = keyboard.next().toLowerCase();
        toUnit = keyboard.next().toLowerCase();

        if (fromUnit.equals("f") && toUnit.equals("c"))
        {
            toValue = 5 * (fromValue - 32) / 9;
        }
        else if (fromUnit.equals("c") && toUnit.equals("f"))
        {
            toValue = 9 * fromValue/5 + 32;
        }
        else if (fromUnit.equals("cm") && toUnit.equals("in"))
        {
            toValue = fromValue/2.54;
        }
        else if (fromUnit.equals("in") && toUnit.equals("cm"))
        {
            toValue = fromValue*2.54;
        }
        else
        {
            isKnownConversion = false;
        }

        if(isKnownConversion)
        {
            outputMessage = "For the value" + fromValue + " as " +fromUnit + " the " + toUnit + " would be "+ toValue;

            System.out.println(outputMessage);
        }
        else
        {
            System.out.println("Unknown unit conversion");
        }

        System.out.println("Processing complete");
    }
}
