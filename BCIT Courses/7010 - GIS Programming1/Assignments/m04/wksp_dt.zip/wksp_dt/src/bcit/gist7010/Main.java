package bcit.gist7010;

import java.util.Scanner;

public class Main {



    public static void main(String[] args) {
        // 
        double hec;
        double SquareMeters;
        double radius;
        Scanner input;

	// write your code here
        //
        System.out.println(" Please enter area by hectares: ");
        input = new Scanner(System.in);
        hec = input.nextDouble();
        SquareMeters = hec*10000;
        radius = Math.pow((SquareMeters/ Math.PI),0.5);
        System.out.println(" Radius of the area of "+hec+" hectares is "+radius+" meters.");
    }
}

