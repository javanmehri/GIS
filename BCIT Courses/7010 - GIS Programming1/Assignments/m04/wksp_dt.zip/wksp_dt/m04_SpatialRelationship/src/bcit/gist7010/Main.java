//==============================================================================
// File         : MAIN.java
//
// Current Author: Mostafa Javanmehri
//
// Previous Author: None
//
// Contact Info: m.javanmehri@gmail.com
//
// Purpose :
//
// This program answers the question of whether a given point is inside, on the
// boundary of or outside of a given shape or area. Also, we are interested in
// whether the given point is near the area (usually defined as within a given
// distance; visualize buffering the shape).
//
// Dependencies: None
//
// Modification Log :
//    --> Created May-06-2016 (fl)
//    --> Updated MMM-DD-YYYY (fl)
//
// =============================================================================

package bcit.gist7010;

import java.util.Scanner;


public class Main {


    // ===========================================================
    // enumerations for spatial relationship
    // ===========================================================
    enum SpatilaRelationship {
        INSIDE, LEFT, RIGHT, TOP, BOTTOM, INSIDE_BUFFER, LEFT_BUFFER,
        RIGHT_BUFFER, TOP_BUFFER, BOTTOM_BUFFER, DISJOINT
    };

    public static void main(String[] args) {

        // ===========================================================
        // Link a Scanner to the keyboard so that we can capture
        // what the user types at the keyboard and pipe that data
        // into the program for processing
        // ===========================================================
        Scanner keyboard;
        keyboard = new Scanner(System.in);

        double xmin, ymin, xmax, ymax, bufferedDistance, xcoord, ycoord;

        // ===========================================================
        // Prompt the user for the data
        // ===========================================================
        System.out.println(" Please enter the following parameters in ordere. After typing each press ENTER key.");
        System.out.println(" xmin, ymin, xmax, ymax, buffered distance, xcoord, ycoord: ");
        xmin = keyboard.nextDouble();
        ymin = keyboard.nextDouble();
        xmax = keyboard.nextDouble();
        ymax = keyboard.nextDouble();
        bufferedDistance = keyboard.nextDouble();
        xcoord = keyboard.nextDouble();
        ycoord = keyboard.nextDouble();

        double bufferedXmin, bufferedYmin, bufferedXmax, bufferedYmax;
        bufferedXmin = xmin - bufferedDistance;
        bufferedYmin = ymin - bufferedDistance;
        bufferedXmax = xmax + bufferedDistance;
        bufferedYmax = ymax + bufferedDistance;

        // ===========================================================
        // Declare a data bucket for relationship, and assume the point
        // and MBR are DISJOINT
        // ===========================================================
        SpatilaRelationship spatilaRelationship = SpatilaRelationship.DISJOINT;

        // ===========================================================
        // Set spatialRelationship
        // ===========================================================
        if (xcoord > xmin && xcoord < xmax && ycoord > ymin && ycoord < ymax)
        {
            spatilaRelationship = SpatilaRelationship.INSIDE;
        }
        else if (xcoord == xmin && ycoord > ymin && ycoord < ymax)
        {
            spatilaRelationship = SpatilaRelationship.LEFT;
        }
        else if (xcoord == xmax && ycoord > ymin && ycoord < ymax)
        {
            spatilaRelationship = SpatilaRelationship.RIGHT;
        }
        else if (ycoord == ymax && xcoord < xmax && xcoord > xmin)
        {
            spatilaRelationship = SpatilaRelationship.TOP;
        }
        else if (ycoord == ymin && xcoord < xmax && xcoord > xmin)
        {
            spatilaRelationship = SpatilaRelationship.BOTTOM;
        }
        else if (xcoord > bufferedXmin && xcoord < bufferedXmax && ycoord > bufferedYmin && ycoord < bufferedYmax)
        {
            spatilaRelationship = SpatilaRelationship.INSIDE_BUFFER;
        }
        else if (xcoord == bufferedXmin && ycoord < bufferedYmax && ycoord > bufferedYmin)
        {
            spatilaRelationship = SpatilaRelationship.LEFT_BUFFER;
        }
        else if (xcoord == bufferedXmax && ycoord < bufferedYmax && ycoord > bufferedYmin)
        {
            spatilaRelationship = SpatilaRelationship.RIGHT_BUFFER;
        }
        else if (ycoord == bufferedYmax && xcoord < bufferedXmax && xcoord > bufferedXmin)
        {
            spatilaRelationship = SpatilaRelationship.TOP_BUFFER;
        }
        else if (ycoord == bufferedYmin && xcoord < bufferedXmax && xcoord > bufferedXmin)
        {
            spatilaRelationship = SpatilaRelationship.BOTTOM_BUFFER;
        }

        // ===========================================================
        // Report the relationship
        // ===========================================================
        System.out.printf(" The relationship of the point is %s of the MBR.", spatilaRelationship);
    }
}
