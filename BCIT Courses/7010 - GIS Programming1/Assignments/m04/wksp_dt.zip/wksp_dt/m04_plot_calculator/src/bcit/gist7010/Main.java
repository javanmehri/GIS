package bcit.gist7010;

//==============================================================================
// File         : Main.java
//
// Current Author: Mostafa Javanmehri
//
// Previous Author: None
//
// Contact Info: m.javanmehri@gamil.com
//
// Purpose : Lab exercise
//
// Dependencies: None
//
// Modification Log :
//    --> Created May-06-2016 (fl)
//    --> Updated MMM-DD-YYYY (fl)
//
// =============================================================================

import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import org.apache.commons.lang3.EnumUtils;

import java.util.Scanner;
import java.util.concurrent.CompletionService;

public class Main {


    // ===========================================================
    // enumerations for the ink types and charges
    // ===========================================================
    enum InkType {
        LINE, POLYGON, ORTHO
    };


    // ===========================================================
    // enumerations for the paper types and charges
    // ===========================================================
    enum PaperType {
        MYLAR, HEAVY, REGULAR
    };

    public static void main(String[] args) {
        // ===========================================================
        // You will need to import Scanner (see below)
        // import java.util.Scanner;
        //
        // Link a Scanner to the keyboard so that we can capture
        // what the user types at the keyboard and pipe that data
        // into the program for processing
        // ===========================================================
        Scanner keyboard;
        keyboard = new Scanner(System.in);


        // ===========================================================
        // Constants for ink and paper charges
        // ===========================================================
        final double REGULAR = 0.50;
        final double HEAVY = 0.75;
        final double MYLAR = 1.00;
        final double LINE = 0.50;
        final double POLYGON = 1.00;
        final double ORTHO = 1.50;


        // ===========================================================
        // Data bucket for the cost per linear inch
        // ===========================================================
        double costPerInch = 0;

        String inkTypeAsString;
        InkType inkType;
        System.out.println(" Enter the ink type (LINE, POLYGON, ORTHO): ");
        inkTypeAsString = keyboard.nextLine().toUpperCase();
        if (EnumUtils.isValidEnum(InkType.class, inkTypeAsString))
        {
            inkType = InkType.valueOf(inkTypeAsString);
        }
        else{
            inkType = InkType.ORTHO;
        }

        String paperTypeAsString;
        PaperType paperType;
        System.out.println(" Enetr the paper type (MYLAR, HEAVY, REGULAR): ");
        paperTypeAsString = keyboard.nextLine().toUpperCase();
        if (EnumUtils.isValidEnum(PaperType.class, paperTypeAsString))
        {
            paperType = PaperType.valueOf(paperTypeAsString);
        }
        else
        {
            paperType = PaperType.MYLAR;
        }

        if (inkType.equals(InkType.ORTHO))
        {
            costPerInch = costPerInch + ORTHO;
        }
        else if (inkType.equals(InkType.POLYGON))
        {
            costPerInch = costPerInch+POLYGON;
        }
        else if (inkType.equals(InkType.LINE))
        {
            costPerInch = costPerInch + LINE;
        }

        if (paperType.equals(PaperType.MYLAR))
        {
            costPerInch = costPerInch + MYLAR;
        }
        else if (paperType.equals(PaperType.HEAVY))
        {
            costPerInch = costPerInch + HEAVY;
        }
        else if (paperType.equals(PaperType.REGULAR))
        {
            costPerInch = costPerInch + REGULAR;
        }

        double width;
        System.out.println(" Enter the width of the plot: ");
        width = keyboard.nextDouble();

        double height;
        System.out.println(" Enter the height of the plot: ");
        height = keyboard.nextDouble();

        int num;
        System.out.println(" Enter the number of plots: ");
        num = keyboard.nextInt();

        double cost;
        cost = costPerInch*Math.max(width, height)*num;

        System.out.printf(" The cost based on the paper, ink type, maximum length and number of plots is %f ", cost);
    }
}
