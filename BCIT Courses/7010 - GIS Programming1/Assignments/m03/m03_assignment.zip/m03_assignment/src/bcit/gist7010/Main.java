package bcit.gist7010;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner keyboard;
        keyboard = new Scanner(System.in);

        // Three constants for the different pricing of the three types of paper (all prices are per inch)
        final Double price_paper_mylar = 1.00, price_paper_heavy = 0.75, price_paper_regular = 0.50;

        // Three constant for the different pricing for the three types of ink (all prices are per inch)
        final Double price_ink_line = 0.50, price_ink_polygon = 1.00, price_ink_ortho = 1.50;

        // a data bucket for the type of paper to use (mylar, heavy, regular)
        String type_paper;

        // a data bucket for the type of plot (line, polygon, ortho)
        String type_plot;

        // a data bucket for the width of the plot
        Double width = Double.NaN;

        // a data bucket for the height of the plot
        Double height = Double.NaN;

        // a data bucket for the number of plots
        Integer numberOfPlots = 0;

        // a data bucket for the ink charge
        Double charge_ink = Double.NaN;

        // a data bucket for the paper charge
        Double charge_paper = Double.NaN;

        // a data bucket for the total cost
        Double cost;

        // Prompt the user for the type of paper (mylar, heavy, regular), and set the value of the corresponding bucket
        System.out.println(" Please enter the type of paper to use (mylar, heavy, regular): ");
        type_paper = keyboard.next().toLowerCase();

        // Prompt the user for the type of plot (line, polygon, ortho), and set the value of the corresponding bucket
        System.out.println(" Enter the type of plot (line, polygon, ortho): ");
        type_plot = keyboard.next().toLowerCase();

        // Prompt the user for the width of the plot, and set the value of the corresponding bucket
        System.out.println(" Enter the (width) of the plot (in inches) : ");
        width = keyboard.nextDouble();

        // Prompt the user for the height of the plot, and set the value of the corresponding value
        System.out.println(" Enter the (height) of the plot (in inches): ");
        height = keyboard.nextDouble();

        // Prompt the user for the number of plots, and set the value of the corresponding value
        System.out.println(" Enter the number of plots: ");
        numberOfPlots = keyboard.nextInt();

        // A multipath selection that resolves the ink type and charge
        if (type_plot.equals("line"))
        {
            charge_ink = price_ink_line;
        }
        else if (type_plot.equals("polygon"))
        {
            charge_ink = price_ink_polygon;
        }
        else if (type_plot.equals("ortho"))
        {
            charge_ink = price_ink_ortho;
        }

        // A multipath selection that resolves the paper type and charge
        if (type_paper.equals("mylar"))
        {
            charge_paper = price_paper_mylar;
        }
        else if (type_paper.equals("heavy"))
        {
            charge_paper = price_paper_heavy;
        }
        else if (type_paper.equals("regular"))
        {
            charge_paper = price_paper_regular;
        }

        // calculate the cost based on the paper, ink type, maximum length and number of plots
        cost = (charge_ink+charge_paper)*Math.max(width, height)*numberOfPlots;

        // Report
        System.out.printf(" The total cost based on the papar, ink type, maximum length and number of plots is %f", cost);

    }
}
